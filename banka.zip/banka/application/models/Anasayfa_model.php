<?php 
class Anasayfa_model extends CI_model{
	public function get($where,$table){
		return $this->db->where($where)->get($table)->row();
	}
	public function addata($table,$where){
		return $this->db->insert($table,$where);
	}
	public function update($where,$data){
		return $this->db->where($where)->update($table,$data);
	}
	public function allCount($table){
	    $query=$this->db->count_all_results($table); // tüm veri çekmek için
        return $query;
	}
	public function allSum($table,$column){
	    $query=$this->db
        ->select_sum($column)
        ->from($table)
        ->get();
         $result = $query->result();

         return $result[0]->$column;
	}
}

?>