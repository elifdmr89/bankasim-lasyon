<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Elif Banka <?php if(!empty($tittle)) {echo $tittle;} ?> </title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="MyraStudio" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/logo/logo.png">

    <!-- App css -->
    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/css/theme.min.css" rel="stylesheet" type="text/css" />
<?php if( (!empty($info)) && $info=="tablo"){ ?>
 <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet" type="text/css" />
 <link href="<?php echo base_url();?>assets/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" class="init">
    
$(document).ready(function() {
    $('#example').DataTable();
} );

 </script>
<?php }
else{

}?>
</head>