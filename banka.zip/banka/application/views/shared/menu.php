<body>

    <!-- Begin page -->
    <div id="layout-wrapper">

        <header id="page-topbar">
            <div class="navbar-header">

                <div class="d-flex align-items-left">
                    <button type="button" class="btn btn-sm mr-2 d-lg-none px-3 font-size-16 header-item waves-effect"
                        id="vertical-menu-btn">
                        <i class="fa fa-fw fa-bars"></i>
                    </button>

                </div>

                <div class="d-flex align-items-center">

                


                    <div class="dropdown d-inline-block ml-2">
                        <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="rounded-circle header-profile-user" src="<?php echo base_url(); ?>assets/images/logo/logo.png" alt="Header Avatar">
                            <span class="d-none d-sm-inline-block ml-1">Elif Demir Banka/ Çıkış</span>
                            <i class="mdi mdi-chevron-down d-none d-sm-inline-block"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-right">
                            
                            
                         
                            <a class="dropdown-item d-flex align-items-center justify-content-between"
                                href="logout/index">
                                <span>Çıkış</span>
                            </a>
                        </div>
                    </div>

                </div>
            </div>
        </header>

        <!-- ========== Left Sidebar Start ========== -->
        <div class="vertical-menu">

            <div data-simplebar class="h-100">

                <!--- Sidemenu -->
                <div id="sidebar-menu">
                    <!-- Left Menu Start -->
                    <ul class="metismenu list-unstyled" id="side-menu">
                        <li class="menu-title">Menu</li>
                        <?php if($this->session->userdata('oturum')==true)
                       {if($this->session->userdata('id')==27){  
                         ?>
                         <li>
                            <a href="kul-bigileri-admin" class="waves-effect"><i class='bx bx-money'></i><span>Admin Kullanıcı Bilgileri</span></a>
                        </li>
                    <?php }else{ ?>
                        <li>
                            <a href="kul-bigileri" class="waves-effect"><i class='bx bx-money'></i><span>Kullanıcı Bilgileri</span></a>
                        </li>

                        <li>
                            <a href="para-yatirma" class="waves-effect"><i class='bx bx-money'></i><span>Para Yatırma</span></a>
                        </li>


                        <li><a href="para-cekme" class=" waves-effect"><i class="bx bx-money"></i><span>Para Çekme</span></a></li>

                        <li><a href="para-havale" class=" waves-effect"><i class="bx bx-money"></i><span>Havale Gönderme</span></a></li>
                        <li><a href="para-doviz" class=" waves-effect"><i class="bx bx-money"></i><span>Döviz İşlemleri</span></a></li>
                        <li><a href="para-hesap" class=" waves-effect"><i class="bx bx-money"></i><span>Hesap Hareketlerim</span></a></li>
                    <?php } }?>
                    </ul>
                </div>
                <!-- Sidebar -->
            </div>
        </div>