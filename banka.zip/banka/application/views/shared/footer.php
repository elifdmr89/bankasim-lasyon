  <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6">
                            2020 © Elif Bank
                        </div>
                        <div class="col-sm-6">
                            <div class="text-sm-right d-none d-sm-block">
                                Design & Develop by Elif Bank
                            </div>
                        </div>
                    </div>
                </div>
            </footer>


       </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->

    <!-- Overlay-->
    <div class="menu-overlay"></div>

  <!-- jQuery  -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/metismenu.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/waves.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <?php if((!empty($info)) && $info=="tablo"){ ?>
     <script src="<?php echo base_url();?>assets/js/jquery-3.5.1.js"></script>
     <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"></script>
     <script src="<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js"></script>
    <?php } ?>
    <!-- Morris Custom Js-->
    <script src="<?php echo base_url();?>assets/pages/dashboard-demo.js"></script>

    <!-- App js -->
    <script src="<?php echo base_url();?>assets/js/theme.js"></script>

</body>



</html>