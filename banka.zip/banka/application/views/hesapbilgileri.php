<div class="main-content">

            <div class="page-content">
                <div class="container-fluid">
                    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Para miktarı</th>
                <th>Açıklama</th>
                
            </tr>
        </thead>
        <tbody>
            <?php if(isset($toplam->toplam)) {
               ?>
            <tr>
                <td><?php echo $toplam->toplam; ?></td>
                <td>Güncel Bakiyeniz</td>
               
            </tr>
            <?php } ?>
            <?php if(isset($dolar_a->miktar)) {
               ?>
            <tr>
                <td><?php echo $dolar_a->miktar; ?></td>
                <td>Dolar Alımı</td>
               
            </tr>
            <?php } ?>
             <?php if(isset($dolar_s->miktar)) {
               ?>
            <tr>
                <td><?php echo $dolar_s->miktar; ?></td>
                <td>Dolar Satımı</td>
               
            </tr>
            
               <?php }
               if(isset($yatirilan)){

                foreach($yatirilan as $value){

               ?>
            <tr>
                <td><?php echo $value->miktar; ?></td>
                <td>Yatırılan Para</td>
               
            </tr>
            <?php } }  ?>
            <?php  if(isset($cekilen)){

                foreach($cekilen as $value){

               ?>
            <tr>
                <td><?php echo $value->miktar; ?></td>
                <td>Çekilen Para</td>
               
            </tr>
            <?php } }  ?>
            <?php  if(isset($havale_giden)){

                foreach($havale_giden as $value){

               ?>
            <tr>
                <td><?php echo $value['kadi']; ?> Kişiye <?php echo $value['miktar']; ?></td>
                <td>Havale Edilen </td>
               
            </tr>
            <?php } }  ?>
              <?php  if(isset($havale_gelen)){

                foreach($havale_gelen as $value){

               ?>
            <tr>
                <td><?php echo $value['kadi']; ?> Kişiden <?php echo $value['miktar']; ?></td>
                <td>Havale ile Gelen </td>
               
            </tr>
            <?php } }  ?>
        </tbody>
        <tfoot>
            <tr>
               <th>Para miktarı</th>
                <th>Açıklama</th>
            </tr>
        </tfoot>
    </table>


                </div> <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

           