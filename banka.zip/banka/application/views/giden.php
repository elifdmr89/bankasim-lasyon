<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">
            <div class="page-container" style="margin-bottom: 50px;">
             
            </div>
            
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                 
                    <tr>
                        <th>Toplam Para</th>
                        <th>İşlemler</th>
                        
                    </tr>
                    
                </thead>
                <tbody>
                   <?php if (isset($paraBilgi->id)) {
                       
                    
                    
                       ?>
                       <tr>
                        
                        <td><?php echo $paraBilgi->toplam; ?></td>
                        
                        
                        <td> <button type="button" class="btn btn-success" data-toggle="modal" data-target="#yatirPara"> Para Çekme</button>
                         <!--Modal için-->
                         <div class="modal fade" id="yatirPara" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Para Çekme <i class="bx bx-money"></i></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                              </button>
                          </div>
                          <div class="modal-body">
                             <form method="post" action="<?php echo base_url('Para/paragiden'); ?>">
                                <input type="hidden" name="id" value="<?php echo $paraBilgi->id; ?>">
                                <input type="hidden" name="k_id" id="Txtdegertoplam" value="<?php echo $paraBilgi->k_id; ?>">
                                <input type="hidden" name="para_toplam" value="<?php echo $paraBilgi->toplam; ?>">
                                <label for="lname">Ad</label><br>
                                <input  class="form-control"  value="<?php echo $paraBilgi->toplam; ?>" disabled type="text"><br>
                                <label for="lname">Çekilecek Para Miktarını Girin</label><br>
                                <input class="form-control" value="" id="Txtdeger" type="number" name="para_giden"  max="5000"><br><br>
                                
                                
                                <button type="submit" id="btnAddProfile" class="btn btn-primary">Para Çekme</button>
                            </form>
                        </div>
                        
                    </div>
                </div>
            </div> 


        </td>
    </tr>
<?php  }?>

</tbody>
<tfoot>
    <tr>
        <th>Toplam Bakiye</th>
        <th>İşlemler</th>
    </tr>
</tfoot>
</table>


</div> <!-- container-fluid -->
</div>
<!-- End Page-content -->

  <!--       <script>
            $("#btnAddProfile").click(function(){
                 $deger=$("#Txtdeger").attr('value');
                 $toplam=$("#Txtdegertoplam").attr('value');
                 alert($deger);
                 }); 


         </script>-->