          <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">
                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <h4 class="mb-0 font-size-18"><?php echo $tittle; ?></h4>

                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Elif Demir Banka </a></li>
                                        <li class="breadcrumb-item active"><?php echo $tittle; ?></li>
                                    </ol>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-xl-3 col-md-6">
                            <div class="card">
                                <div class="card-body">
                                    <i class="bx bx-layer float-right m-0 h2 text-muted"></i>
                                    <h6 class="text-muted text-uppercase mt-0">Döviz işlemleri</h6>
                                    <?php if (isset($dolar->id) && ($dolar->miktar>0) && ($dolar->alim==1)) { 
                                        ?>
                                        <h4>Toplam TL Bakiyen</h4>
                                        <label class="form-control"><?php echo $toplampara->toplam; }?></label>
                                        <?php if (isset($dolar->id)) { 
                                            ?>
                                            <h4>Toplam Dolar Bakiyen</h4>
                                            <label class="form-control"><?php echo $dolar->miktar; }?></label>
                                            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#dovizAlma"> Dolar Al </button>
                                            <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#dovizSatma"> Dolar Sat </button>
                                            <h3 class="mb-3" data-plugin="counterup"></h3>
                                        </div>
                                    </div>
                                </div>
                                <!--Modal-->
                                <div class="modal fade" id="dovizAlma" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Dolar Alma <i class="bx bx-dollar-circle float-right m-0 h2 text-muted"></i></h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <span aria-hidden="true">&times;</span>
                                      </button>
                                  </div>
                                  <div class="modal-body">
                                  
                                        <form method="post" action="<?php echo base_url('Para/dolaralma'); ?>">
                                            <input type="hidden" name="id" value="<?php echo $toplampara->id; ?>">
                                            <input type="hidden" name="k_id" id="Txtdegertoplam" value="<?php echo $toplampara->k_id; ?>">
                                            <input type="hidden" name="para_toplam" value="<?php echo $toplampara->toplam; ?>">

                                            <label for="lname">Alınacak Dolar Miktarı</label><br>
                                            <input class="form-control" value="" id="Txtdeger" type="number" name="dolarpara"><br><br>


                                            <button type="submit" id="btnAddProfile" class="btn btn-primary">Dolar Al</button>
                                        </form>
                                  
                                </div>

                            </div>
                        </div>
                    </div>
                    <!--Modal-->
                    <!--Modal2-->
                    <div class="modal fade" id="dovizSatma" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Dolar Satma <i class="bx bx-dollar-circle float-right m-0 h2 text-muted"></i></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                          </button>
                      </div>
                      <div class="modal-body">
                        <?php if (isset($dolar->id) && ($dolar->miktar>0) && ($dolar->alim==1)) { 
                            ?>
                            <form method="post" action="<?php echo base_url('Para/dolarsatma'); ?>">
                                <input type="hidden" name="id_s" value="<?php echo $toplampara->id; ?>">
                                <input type="hidden" name="k_id_s" id="Txtdegertoplam" value="<?php echo $toplampara->k_id; ?>">
                                <input type="hidden" name="para_toplam_s" value="<?php echo $toplampara->toplam; ?>">

                                <label for="lname">Satılacak Dolar Miktarı</label><br>
                                <input class="form-control" value="" id="Txtdeger" type="number" max="<?php echo $dolar->miktar; ?>" name="dolarpara_s"><br><br>
                                
                                
                                <button type="submit" id="btnAddProfile" class="btn btn-primary">Dolar Sat</button>
                            </form>
                        <?php }else{ ?>
                            Dolarınız yok
                        <?php } ?>
                    </div>

                </div>
            </div>
        </div>
        <!--Modal2-->
        <div class="col-xl-3 col-md-6">
            <div class="card">
                <div class="card-body">
                    <i class="bx bx-dollar-circle float-right m-0 h2 text-muted"></i>
                    <h6 class="text-muted text-uppercase mt-0">Dolar Kuru</h6>
                    <h3 class="mb-3"><span data-plugin="counterup">TL</span></h3>
                    <label class="form-control">Dolar Alış</label>
                    <label class="form-control"><?php if(isset($dolaralis)){ echo $dolaralis; } ?></label><br>
                    <label class="form-control">Dolar Satış</label>
                    <label class="form-control"><?php if(isset($dolarsatis)){ echo $dolarsatis;} ?></label>
                </div>
            </div>
        </div>



    </div>
    <!-- end row -->


</div> <!-- container-fluid -->
</div>
<!-- End Page-content -->

