<div class="main-content">

            <div class="page-content">
                <div class="container-fluid">
                    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Kullanıcı</th>
                <th>Bakiye</th>
                
            </tr>
        </thead>
        <tbody>
            <?php  if(isset($uyeBilgi)){

                foreach($uyeBilgi as $value){

               ?>
            <tr>
                <td><?php echo $value['kadi']; ?> </td>
                <td> <?php echo $value['toplam']; ?> </td>
               
            </tr>
            <?php } }  ?>
        </tbody>
        <tfoot>
            <tr>
               <th>Kullanıcı</th>
                <th>Bakiye</th>
            </tr>
        </tfoot>
    </table>


                </div> <!-- container-fluid -->
            </div>
            <!-- En