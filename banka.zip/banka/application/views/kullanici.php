<div class="main-content">

        <div class="page-content">
    <div class="container-fluid">
    <div class="page-container" style="margin-bottom: 50px;">
     
    </div>
       
               <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
         
            <tr>
                <th>Kullanici ad</th>
                <th>Kullanici eposta</th>
                <th>İşlemler</th>
             
            </tr>
            
        </thead>
        <tbody>
           <?php if (isset($uyeBilgi->id)) {
   
                
            
           ?>
            <tr>
                
                <td><?php echo $uyeBilgi->kadi; ?></td>
                <td><?php echo $uyeBilgi->eposta; ?></td>
               
                <td> <button type="button" class="btn btn-success" data-toggle="modal" data-target="#kulDuzenle"> Düzenle</button>
                 <!--Modal KulDuzenle için-->
             <div class="modal fade" id="kulDuzenle" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Kullanıcı Düzenle</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                 <form method="post" action="<?php echo base_url('kullanici/kulduzenle'); ?>">
                    <input type="hidden" name="id" value="<?php echo $uyeBilgi->id; ?>">
                    <label for="lname">Ad</label><br>
                      <input  class="form-control"  value="<?php echo $uyeBilgi->kadi; ?>" type="text" name="kul_ad"><br>
                      <label for="lname">eposta</label><br>
                      <input class="form-control" value="<?php echo $uyeBilgi->eposta ;?>" type="text" name="kul_eposta"><br><br>
                      <label for="lname">Şifre </label><br>
                      <input class="form-control" value="yeni şifreni gir" type="password" name="kul_sifre"><br><br>
                    
                    <button type="submit" class="btn btn-primary">Düzenle</button>
                </form>
              </div>
             
            </div>
          </div>
        </div> 


    </td>
            </tr>
            <?php  }?>

        </tbody>
        <tfoot>
            <tr>
                <th>Kullanıcı ad</th>
                <th>Kullanıcı eposta</th>
                <th>İşlemler</th>
            </tr>
        </tfoot>
    </table>


                </div> <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

         