<div class="main-content">

        <div class="page-content">
    <div class="container-fluid">
    <div class="page-container" style="margin-bottom: 50px;">
     
    </div>
       
               <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
         
            <tr>
                <th>Toplam Para</th>
                <th>Kullanıcı seç</th>
                <th>Para Miktarı</th>
                <th>İşlem</th>
             
            </tr>
            
        </thead>
        <tbody>
            <form method="post" action="<?php echo base_url('Para/havaleislem'); ?>">
           <?php if (isset($paraBilgi->id)) { 
           ?>
            <tr>
                
                <td><?php echo $paraBilgi->toplam; } ?> </td>
                <td><select class="form-control" name="gid">
                <?php foreach ($kullanici as $value){
                ?>
                <?php if($kul_id != $value['id'] ){?>
                <option value="<?php echo $value['id']; ?>"><?php echo $value['kadi']; ?></option>
                <?php } } ?>

                </select></td>
                <td><input type="number" name="havaleMiktar" value="" placeholder="Para Miktarı Gir"></td>
                <td><input type="hidden" name="kulid" value="<?php echo $kul_id; ?>"> 
                    <input type="hidden" name="toplam" value="<?php  if(isset($paraBilgi->toplam)){echo $paraBilgi->toplam; } ?>">
                    <?php if(isset($paraBilgi->id)){ ?>
                    <button type="submit" id="btnAddProfile" class="btn btn-primary">Para Havale</button>
                <?php }else{ ?>
                    Havale Edicek Paranız yok kredi çekin 
                <?php }?>
                </td>
            </tr>
           
            </form>
        </tbody>
        <tfoot>
            <tr>
                 <th>Toplam Para</th>
                <th>Kullanıcı seç</th>
                <th>Para Miktarı</th>
                <th>İşlem</th>
            </tr>
        </tfoot>
    </table>


                </div> <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

  <!--       <script>
            $("#btnAddProfile").click(function(){
                 $deger=$("#Txtdeger").attr('value');
                 $toplam=$("#Txtdegertoplam").attr('value');
                 alert($deger);
                 }); 


         </script>-->