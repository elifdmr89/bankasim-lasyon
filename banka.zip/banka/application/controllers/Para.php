<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class Para extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('para_model');
		$this->load->helper('form');
		$this->load->library('form_validation');
		$session_data = $this->session->userdata('oturum');
		if($session_data==NULL){
			redirect('login', 'refresh');
		}
	}
	
	public function index()
	{
		if($this->session->userdata('oturum')==true)
		{

			$id=$this->session->userdata('id');

			$this->load->model('para_model');
			$this->load->helper('form');
			$this->load->library('form_validation');
			$where='k_id='.$id;
			$get =$this->para_model->get($where,'bakiye');
			$gelen =$this->para_model->get($where,'gelen');
			$data['paraBilgi']=$get;
			$data['gelen']=$gelen;

			$data['tittle']="Para Yatırma Banka";
			$this->load->view('shared/header',$data);
			$this->load->view('shared/menu');
			$this->load->view('yatirma',$data);
			$this->load->view('shared/footer');
		}
		else{
			redirect(base_url('login'));
		}


	}
	public function paraDuzenle(){
		if($this->input->method() == "post"){
			$id= $this->input->post('id');
			$paragelen=$this->input->post('para_yatirilan');
			$toplampara=$this->input->post('para_toplam');
			$t_p=(int)$paragelen+(int)$toplampara;
			//echo $toplampara; die();
			$data = array(
				'toplam' => $t_p,
				'id'   => $this->input->post('id'),
				'k_id'=>$this->input->post('k_id')
			);
			$gelen =array(
				'bakiye_id' =>$this->input->post('id'),
				'k_id'=>$this->input->post('k_id'),
				'miktar'=>$paragelen
			);
			$this->db->update('bakiye', $data, array('id' => $id));
			$this->para_model->addata('gelen',$gelen);
			redirect('para-yatirma', 'refresh');

		}
	}

	public function paracekme(){
		if($this->session->userdata('oturum')==true)
		{

			$id=$this->session->userdata('id');

			$this->load->model('para_model');
			$this->load->helper('form');
			$this->load->library('form_validation');
			$where='k_id='.$id;
			$get =$this->para_model->get($where,'bakiye');
			$gelen =$this->para_model->get($where,'giden');
			$data['paraBilgi']=$get;


			$data['tittle']="Para Çekme Banka";
			$this->load->view('shared/header',$data);
			$this->load->view('shared/menu');
			$this->load->view('giden',$data);
			$this->load->view('shared/footer');
		}
		else{
			redirect(base_url('login'));
		}


	}
	public function paragiden(){
		if($this->input->method() == "post"){
			$id= $this->input->post('id');
			$paragiden=$this->input->post('para_giden');
			$toplampara=$this->input->post('para_toplam');
			$t_p=(int)$toplampara-(int)$paragiden;
			$data = array(
				'toplam' => $t_p,
				'id'   => $this->input->post('id'),
				'k_id'=>$this->input->post('k_id')
			);
			$giden =array(
				'bakiye_id' =>$this->input->post('id'),
				'k_id'=>$this->input->post('k_id'),
				'miktar'=>$paragiden
			);
			$this->db->update('bakiye', $data, array('id' => $id));
			$this->para_model->addata('giden',$giden);
			redirect('para-cekme', 'refresh');

		}


	}

	public function parahavale(){
		if($this->session->userdata('oturum')==true)
		{

			$id=$this->session->userdata('id');
			$data['kul_id']=$this->session->userdata('id');
			$this->load->model('para_model');
			$this->load->helper('form');
			$this->load->library('form_validation');
			$where='k_id='.$id;
			$get =$this->para_model->get($where,'bakiye');
			$kul=$this->para_model->getAll('uyeler');

           //$gelen =$this->para_model->get($where,'giden');
			$data['paraBilgi']=$get;
			$data['kullanici']= $kul -> result_array();

			$data['tittle']="Para Çekme Havale";
			$this->load->view('shared/header',$data);
			$this->load->view('shared/menu');
			$this->load->view('havale',$data);
			$this->load->view('shared/footer');
		}
		else{
			redirect(base_url('login'));
		}


	}
	public function havaleislem(){
		if($this->input->method() == "post"){
			$where='k_id='.$this->input->post('kulid');
			$where_g='k_id='.$this->input->post('gid');
			$get =$this->para_model->get($where,'bakiye');
			$get_g=$this->para_model->get($where_g,'bakiye');
			if(isset($get_g->id)){
			$toplampara_g=$get_g->toplam+$this->input->post('havaleMiktar');
				}
				else{
				$toplampara_g=$this->input->post('havaleMiktar');
				}
			$data = array(
				'k_id' => $this->input->post('kulid'),
				'g_id'   => $this->input->post('gid'),
				'miktar'=>$this->input->post('havaleMiktar')
			);
			$toplampara=(int)$this->input->post('toplam')-(int)$this->input->post('havaleMiktar');
			$bakiye = array(
				'k_id' => $this->input->post('kulid'),
				'toplam'   => $toplampara
				
			);
			$bakiye_g = array(
				'k_id' => $this->input->post('gid'),
				'toplam'   => $toplampara_g
				
			);

			
			$kullanici_id=$this->input->post('kulid');
			if(empty($get_g->id)){
			$this->db->update('bakiye', $bakiye, array('k_id' => $this->input->post('kulid')));
			$this->para_model->addata('bakiye',$bakiye_g);
			$this->para_model->addata('havale',$data);
		}
		else{
			$this->db->update('bakiye', $bakiye, array('k_id' => $this->input->post('kulid')));
			$this->db->update('bakiye', $bakiye_g, array('k_id' => $this->input->post('gid')));
			$this->para_model->addata('havale',$data);
		}
			redirect('para-havale', 'refresh');
		}
		}

	

	public function paradoviz(){
		if($this->session->userdata('oturum')==true)
		{

			$id=$this->session->userdata('id');
			$where='k_id='.$id;
			$where2='k_id='.$id.' and alim=1';
			//$where3='k_id='.$id.' and alim=0';
			$bakiye =$this->para_model->get($where,'bakiye');
			$dolar =$this->para_model->get($where2,'dolar');
			//$dolarsatis =$this->para_model->get($where3,'dolar');
			$this->load->model('para_model');
			$this->load->helper('form');
			$this->load->library('form_validation');
			//Dolar Kuru
			$get = file_get_contents('https://www.tcmb.gov.tr/kurlar/today.xml');
			$doviz = simplexml_load_string($get);
			$usd_alis = $doviz ->Currency[0]->BanknoteBuying;
			$usd_satis = $doviz ->Currency[0]->BanknoteSelling;


			$data['dolaralis']=$usd_alis;
			$data['dolarsatis']=$usd_satis;
			$data['toplampara']=$bakiye;
			$data['dolar']=$dolar;
			//$data['dolarsatis']=$dolarsatis;

			$data['tittle']="Döviz";
			$this->load->view('shared/header',$data);
			$this->load->view('shared/menu');
			$this->load->view('doviz',$data);
			$this->load->view('shared/footer');
		}
		else{
			redirect(base_url('login'));
		}


	}
	public function dolaralma(){
	if($this->input->method() == "post"){
			$this->load->model('para_model');
			$this->load->helper('form');
			$this->load->library('form_validation');
			//Dolar Kuru
			$get = file_get_contents('https://www.tcmb.gov.tr/kurlar/today.xml');
			$doviz = simplexml_load_string($get);
			$usd_alis = $doviz ->Currency[0]->BanknoteBuying;
			$usd_satis = $doviz ->Currency[0]->BanknoteSelling;
			$id=$this->session->userdata('id');
			$where='k_id='.$id;
			$where2='k_id='.$id.' and alim=1';
			$dolar =$this->para_model->get($where2,'dolar');
			$bakiye =$this->para_model->get($where,'bakiye');
			$dolarpara=$this->input->post('dolarpara')*$usd_alis;
			$bakiye_after=$this->input->post('para_toplam')-$dolarpara;
		
			if(isset($dolar->id)){
				$t_d=$this->input->post('dolarpara')+$dolar->miktar;
				$data = array(
				'k_id' => $this->input->post('k_id'),
				'b_id'   => $this->input->post('id'),
				'miktar'=>$t_d,
				'alim'=>1
			);
				$bakiye_data = array(
				'k_id' => $this->input->post('k_id'),
				'id'   => $bakiye->id,
				'toplam'=>$bakiye_after,
				
			);
			$this->db->update('dolar', $data, array('k_id' => $this->input->post('k_id')));
			$this->db->update('bakiye', $bakiye_data, array('k_id' => $this->input->post('k_id')));
			}
			else{
				$data = array(
				'k_id' => $this->input->post('k_id'),
				'b_id'   => $this->input->post('id'),
				'miktar'=>$this->input->post('dolarpara'),
				'alim'=>1
			);
				$bakiye_data = array(
				'k_id' => $this->input->post('k_id'),
				'id'   => $bakiye->id,
				'toplam'=>$bakiye_after,
				
			);
			$this->db->update('bakiye', $bakiye_data, array('k_id' => $this->input->post('k_id')));
			$this->para_model->addata('dolar',$data);	
			}
			
			redirect('para-doviz', 'refresh');


	}
}
	public function dolarsatma(){
			if($this->input->method() == "post"){
			$this->load->model('para_model');
			$this->load->helper('form');
			$this->load->library('form_validation');
			//Dolar Kuru
			$get = file_get_contents('https://www.tcmb.gov.tr/kurlar/today.xml');
			$doviz = simplexml_load_string($get);
			$usd_alis = $doviz ->Currency[0]->BanknoteBuying;
			$usd_satis = $doviz ->Currency[0]->BanknoteSelling;
			$id=$this->session->userdata('id');
			$where3='k_id='.$id.' and alim=1';
			$where2='k_id='.$id.' and alim=0';
			$where='k_id='.$id;
			$dolar =$this->para_model->get($where3,'dolar');
			$dolar_s =$this->para_model->get($where2,'dolar');
			$bakiye =$this->para_model->get($where,'bakiye');
			$dolarpara=$this->input->post('dolarpara_s')*$usd_satis;
			$bakiye_after=$this->input->post('para_toplam_s')+$dolarpara;
		

			if(isset($dolar_s->id)){
				$t_d=$dolar->miktar-$this->input->post('dolarpara_s');
				$data_d = array(
				'id'=>$dolar->id,
				'k_id' => $this->input->post('k_id_s'),
				'b_id'=>$this->input->post('id_s'),
				'miktar'=>$t_d,
				'alim'=>1
				);
				$data = array(
				'k_id' => $this->input->post('k_id_s'),
				'b_id'=>$this->input->post('id_s'),
				'miktar'=>$this->input->post('dolarpara_s'),
				'alim'=>0
				);

				$bakiye_data = array(
				'k_id' => $this->input->post('k_id_s'),
				'id'   => $bakiye->id,
				'toplam'=>$bakiye_after,
				
			);
			$this->db->update('dolar', $data, array('id' =>$dolar_s->id));
			$this->db->update('dolar', $data_d, array('id' =>$dolar->id));
			$this->db->update('bakiye', $bakiye_data, array('k_id' => $this->input->post('k_id_s')));
			}
			else{
				$t_d=$dolar->miktar-$this->input->post('dolarpara_s');
				$data_d = array(
				'id'=>$dolar->id,
				'k_id' => $this->input->post('k_id_s'),
				'b_id'=>$this->input->post('id_s'),
				'miktar'=>$t_d,
				'alim'=>1
			);
				$data = array(
				'k_id' => $this->input->post('k_id_s'),
				'b_id'=>$this->input->post('id_s'),
				'miktar'=>$this->input->post('dolarpara_s'),
				'alim'=>0
			);
				$bakiye_data = array(
				'k_id' => $this->input->post('k_id_s'),
				'id'   => $bakiye->id,
				'toplam'=>$bakiye_after,
				
			);

			$this->db->update('bakiye', $bakiye_data, array('k_id' => $this->input->post('k_id_s')));
			
			$this->para_model->addata('dolar',$data);

			$this->db->update('dolar', $data_d, array('id' => $dolar->id));	
			}
			
			redirect('para-doviz', 'refresh');


	}

	}
	public function parahesap(){//Burda kaldım
		if($this->session->userdata('oturum')==true)
		{   $id=$this->session->userdata('id');
			$where='k_id='.$id;
			$where3='k_id='.$id.' and alim=1';
			$where2='k_id='.$id.' and alim=0';
			//Dolar bilgileri
			$dolar_a =$this->para_model->get($where3,'dolar');
			$dolar_s =$this->para_model->get($where2,'dolar');
			//toplamBakiye
			$toplam=$this->para_model->get($where,'bakiye');
			//yatirilan para
			$yatirilan=$this->para_model->getA($where,'gelen');
			//cekilen para
			$cekilen=$this->para_model->getA($where,'giden');
			//havale giden para
			$havale_giden = $this->db->query("select uyeler.kadi as kadi,havale.miktar as miktar from uyeler inner join havale on uyeler.id=havale.g_id where havale.g_id=".$id);
			$havale_giden_para=$havale_giden->result_array();
			//havale gelen para
			$havale_gelen=$this->db->query("select uyeler.kadi as kadi,havale.miktar as miktar from uyeler inner join havale on uyeler.id=havale.g_id where havale.k_id=".$id);
			$havale_gelen_para=$havale_gelen->result_array();

			$data['tittle']="Hesap Bilgileri";
			$data['dolar_a']=$dolar_a;
			$data['dolar_s']=$dolar_s;
			$data['toplam']=$toplam;
			$data['yatirilan']=$yatirilan;
			$data['cekilen']=$cekilen;
			$data['havale_giden']=$havale_giden_para;
			$data['havale_gelen']=$havale_gelen_para;



			$this->load->view('shared/header',$data);
			$this->load->view('shared/menu');
			$this->load->view('hesapbilgileri',$data);
			$this->load->view('shared/footer');
		}
	}

}