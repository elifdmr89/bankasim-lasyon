<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class Anasayfa extends CI_Controller {

	
		public function index()
		{
			if($this->session->userdata('oturum')==true)
			{
		   $this->load->model('anasayfa_model');
           $this->load->helper('form');
           $this->load->library('form_validation');
		   $data['tittle']="Anasayfa banka";
		   $this->load->view('shared/header',$data);
		   $this->load->view('shared/menu');
		   $this->load->view('anasayfa',$data);
		   $this->load->view('shared/footer');
		}
		else{
			redirect(base_url('login'));
		}
	

		}
}
