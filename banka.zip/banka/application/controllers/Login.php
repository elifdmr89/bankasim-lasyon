<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

		public function index()
		{
		  
		  $this->load->view('shared/header');
		  $this->load->view('login');
		}
		
		public function logindata()
		{
			if($this->input->method() == "post"){

			$this->form_validation->set_rules('sifre','kullanıcı adı','trim|required');
			$this->form_validation->set_rules('eposta','kullanıcı adı','trim|required[uyeler.eposta]');
			}

			if($this->form_validation->run() == FALSE ){
				echo validation_errors();
			}
			else{
				$query =$this->common_model->get([
				'sifre' => sha1(md5(strip_tags(trim($this->input->post('sifre',true))))),
				'eposta'=> strip_tags(trim($this->input->post('eposta',true)))
				],'uyeler');
				if($query){
					$this->session->set_userdata([
						'oturum' =>true,
						'id' =>$query->id,
						'kadi' =>$query->kadi,
						'eposta' =>$query->eposta
					]);
					
              redirect(base_url('anasayfa'));
				}else{
					echo "hatali giriş";
				}
			}
		}
	
		

}
