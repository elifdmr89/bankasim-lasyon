<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class Kullanici extends CI_Controller {
public function __construct(){
        parent::__construct();
        $this->load->model('kullanici_model');
        $this->load->helper('form');
        $this->load->library('form_validation');
       $session_data = $this->session->userdata('oturum');
        if($session_data==NULL){
            redirect('login', 'refresh');
        }
	}
	
		public function index()
		{
			if($this->session->userdata('oturum')==true)
			{

			$id=$this->session->userdata('id');
		
		   $this->load->model('kullanici_model');
           $this->load->helper('form');
           $this->load->library('form_validation');
           $where='id='.$id;
           $get =$this->kullanici_model->get($where,'uyeler');

           $data['uyeBilgi']=$get;
           

		   $data['tittle']="Kullanici banka";
		   $this->load->view('shared/header',$data);
		   $this->load->view('shared/menu');
		   $this->load->view('kullanici',$data);
		   $this->load->view('shared/footer');
		}
		else{
			redirect(base_url('login'));
		}
	

		}
		public function kulduzenle(){
			if($this->input->method() == "post"){
				$id= $this->input->post('id');
			 $data = array(
       	 	'kadi' => $this->input->post('kul_ad'),
        	'eposta' => $this->input->post('kul_eposta'),
        	'sifre' => sha1(md5(strip_tags(trim($this->input->post('kul_sifre',true)))))
			);
			 	$this->db->update('uyeler', $data, array('id' => $id));
				redirect('kul-bigileri', 'refresh');
			}
		}
		public function admin(){
			if($this->session->userdata('oturum')==true)
			{

		
		
		   $this->load->model('kullanici_model');
           $this->load->helper('form');
           $this->load->library('form_validation');
           $kullanici_bakiye=$this->db->query("select uyeler.kadi as kadi,bakiye.toplam as toplam from uyeler inner join bakiye on uyeler.id=bakiye.k_id");
			$kullanici_bakiye=$kullanici_bakiye->result_array();

           $data['uyeBilgi']=$kullanici_bakiye;
           

		   $data['tittle']="Kullanici banka";
		   $this->load->view('shared/header',$data);
		   $this->load->view('shared/menu');
		   $this->load->view('admin',$data);
		   $this->load->view('shared/footer');
		}
		else{
			redirect(base_url('login'));
		}

		}
}
